
import './App.css'
import Card from './Componets/Card'
import Form from './Componets/Form'

function App() {
  

  return (
    <>
      <div className='App'>
        
        <Form/>
        
      </div>
    </>
  )
}

export default App
